# ELANGKREATOR Official V3
Website + Supabase + Admin Auth + CRUD Produk + Order + AI Chatbot + fondasi monetisasi.

## Setup
1. Buat project Supabase.
2. SQL Editor → jalankan `supabase/schema.sql`.
3. Authentication → buat user admin.
4. Edit `assets/js/config.js` dengan Project URL + anon/publishable key.
5. Deploy AI: `supabase functions deploy ai-chat`
6. Set secret: `supabase secrets set OPENAI_API_KEY=YOUR_OPENAI_KEY`
7. Opsional: `supabase secrets set OPENAI_MODEL=gpt-4o-mini`
8. Upload ke GitHub Pages.

## Admin
Buka `/admin.html` dan login memakai Supabase Auth. Dashboard menampilkan order dan memungkinkan tambah produk.

## Security
Jangan taruh service_role atau OPENAI API key di frontend/GitHub. Untuk production, batasi policy authenticated hanya admin dengan role/claim, dan pertimbangkan rate limiting/CAPTCHA pada form/AI.

## Monetisasi siap dikembangkan
Checkout/payment gateway, produk digital + download, membership, subscription, invoice, kupon, affiliate, analytics, email/WhatsApp automation, AI lead scoring.
