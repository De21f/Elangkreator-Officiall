# ELANGKREATOR V7

Upgrade dari V3 menjadi platform bisnis: conversion landing page, katalog, checkout Midtrans, order/lead, ELANG AI, dashboard admin, promo coupon foundation, analytics foundation, dan PWA.

## 1. Frontend
Edit `assets/js/config.js`:
- `SUPABASE_URL` sudah diisi dengan project ELANGKREATOR.
- Isi `SUPABASE_ANON_KEY` dengan Publishable/Anon Key dari Supabase.
- Isi `MIDTRANS_CLIENT_KEY` dengan Client Key Midtrans Sandbox.
- Ganti `WHATSAPP_NUMBER` dengan nomor WhatsApp bisnis Anda.

Jangan masukkan OpenAI API Key atau Midtrans Server Key ke file frontend/GitHub.

## 2. Supabase
SQL Editor → jalankan `supabase/schema.sql`.

Buat akun admin di Authentication.

## 3. Edge Functions
Deploy tiga function:

```bash
supabase functions deploy ai-chat
supabase functions deploy create-payment
supabase functions deploy midtrans-webhook
```

Set secrets:

```bash
supabase secrets set OPENAI_API_KEY=YOUR_OPENAI_KEY
supabase secrets set OPENAI_MODEL=gpt-4o-mini
supabase secrets set MIDTRANS_SERVER_KEY=YOUR_MIDTRANS_SANDBOX_SERVER_KEY
```

Supabase juga menyediakan `SUPABASE_URL` dan service role key pada runtime function; jangan taruh service role key di frontend.

## 4. Midtrans Sandbox
Gunakan Sandbox dahulu. Set Payment Notification URL di Midtrans Dashboard ke:

`https://otadbnwnfetwbhqqhjwj.supabase.co/functions/v1/midtrans-webhook`

Untuk production, ubah `MIDTRANS_PRODUCTION=true` pada secret/function environment dan gunakan Production Server Key + Client Key. Jangan campur credential Sandbox dan Production.

Midtrans Snap mengambil token dari backend dan checkout dibuka di frontend. Webhook memvalidasi signature `SHA512(order_id + status_code + gross_amount + server_key)` dan memperbarui order secara idempotent berdasarkan `order_code`.

## 5. Deploy GitHub Pages
Upload isi folder ini ke repository Pages. `index.html` adalah halaman utama.

## 6. Catatan produksi
- Ganti policy authenticated menjadi khusus admin/role claim.
- Tambahkan rate limit/CAPTCHA untuk lead dan AI.
- Jangan commit secrets.
- Uji pembayaran Sandbox sampai webhook dan status `paid` benar.
- Setelah stabil, baru pindah ke Production.
